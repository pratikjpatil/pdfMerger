package com.tcs.fincore.ReportBuilder.service.runtime;

import org.apache.commons.jexl3.JexlArithmetic;
import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.JexlFeatures;
import org.apache.commons.jexl3.introspection.JexlPermissions;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Centralized JEXL engine factory to keep expression configuration DRY and secure.
 *
 * <p><b>commons-jexl3 3.7.0 compatibility note:</b> 3.7.0 changed two engine-wide defaults that
 * apply at parse time regardless of {@link JexlPermissions}: {@code new}, loops, side-effects and
 * lambda syntax are now disabled unless a {@link JexlFeatures} set explicitly re-enables them.
 * Report templates/formulas were authored and validated against the pre-3.7 (permissive) parser
 * behavior, so both engines here explicitly pass {@link JexlFeatures#createAll()} to preserve
 * that behavior and avoid previously-valid formulas suddenly throwing {@code JexlException} at
 * report-generation time after this dependency bump. This is orthogonal to (and does not weaken)
 * the class-access allowlist below — that is still enforced by {@link JexlPermissions}.
 */
@Component
public class JexlEngineFactory {

    /**
     * Single allowlist shared by every JEXL engine in this app. Anything report formulas/global
     * params need to call must be added here explicitly — this is intentionally narrow.
     */
    private static final JexlPermissions SAFE_PERMISSIONS = JexlPermissions.parse(
            "com.tcs.fincore.ReportBuilder.util.DateUtilsHelper",
            "java.lang.Math",
            "java.lang.String",
            "java.lang.Number",
            "java.math.BigDecimal",
            "java.time.LocalDate",
            "java.time.LocalDateTime"
    );

    public JexlEngine createSecureEngine() {
        return new JexlBuilder()
                .cache(512)
                .strict(true)
                .silent(false)
                .permissions(SAFE_PERMISSIONS)
                .features(JexlFeatures.createAll())
                .create();
    }

    public JexlEngine createCalculationEngine(JexlArithmetic arithmetic) {
        return new JexlBuilder()
                .cache(512)
                .silent(false)
                .strict(true)
                .arithmetic(arithmetic)
                // FIX: previously omitted here, so cell FORMULA expressions ran with JEXL's
                // library-default permissions instead of the same restricted allowlist used by
                // createSecureEngine() — an unintended, weaker sandbox for the one engine that
                // evaluates expressions built (in part) by string-interpolating runtime/user
                // input (see ReportRuntimeService.interpolateFormulaSafe).
                .permissions(SAFE_PERMISSIONS)
                .features(JexlFeatures.createAll())
                .namespaces(Map.of("math", Math.class))
                .create();
    }
}
