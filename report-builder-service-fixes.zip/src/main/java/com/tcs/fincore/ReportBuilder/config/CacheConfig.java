package com.tcs.fincore.ReportBuilder.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJacksonJsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import tools.jackson.databind.jsontype.BasicPolymorphicTypeValidator;
import tools.jackson.databind.jsontype.PolymorphicTypeValidator;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Jackson 3 / Spring Data Redis 4 cache configuration.
 *
 * <p>{@code GenericJackson2JsonRedisSerializer} is deprecated for removal as of Spring Data
 * Redis 4.0 in favor of {@link GenericJacksonJsonRedisSerializer} (Jackson 3-based). The new
 * builder exposes {@code typeValidator(...)} / {@code typePropertyName(...)} hooks that configure
 * polymorphic ("@class") default typing directly, so there's no need to hand-build a
 * {@code JsonMapper} with {@code activateDefaultTypingAsProperty(...)} ourselves.
 *
 * <p>JSR-310 (LocalDate/LocalDateTime/Instant) support ships built into jackson-databind 3.x, so
 * unlike the Jackson 2 version of this class, no separate {@code JavaTimeModule} registration is
 * required.
 */
@Slf4j
@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public CacheManager cacheManager(RedisConnectionFactory connectionFactory) {

        // SECURITY: explicit allowlist restricts polymorphic deserialization to our own model
        // classes (+ a narrow set of safe JDK types). Behavior is unchanged from before the
        // Spring Boot 4.1 / Jackson 3 upgrade.
        PolymorphicTypeValidator typeValidator = BasicPolymorphicTypeValidator.builder()
                .allowIfSubType("com.tcs.fincore.ReportBuilder.model.")
                .allowIfSubType("com.tcs.fincore.ReportBuilder.dto.")
                .allowIfSubType("com.tcs.fincore.ReportBuilder.batch.model.")
                .allowIfSubType("java.util.")
                .allowIfSubType("java.time.")
                .allowIfSubType("java.lang.")
                .build();

        // REQUIRED: default typing (an "@class" property, equivalent to the old NON_FINAL +
        // JsonTypeInfo.As.PROPERTY combination) is what lets GenericJacksonJsonRedisSerializer
        // round-trip concrete classes like ReportTemplate and the Map<String,Object>-typed
        // fields inside it (Cell.variables, dynamicConfig, ...). Safety is enforced by the
        // typeValidator allowlist above, not by omitting type info.
        GenericJacksonJsonRedisSerializer serializer = GenericJacksonJsonRedisSerializer.create(builder -> builder
                .typeValidator(typeValidator)
                .typePropertyName("@class"));

        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(5))
                .disableCachingNullValues()
                .serializeKeysWith(
                        RedisSerializationContext.SerializationPair.fromSerializer(
                                new StringRedisSerializer()))
                .serializeValuesWith(
                        RedisSerializationContext.SerializationPair.fromSerializer(serializer));

        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();
        cacheConfigurations.put("reportTemplates", defaultConfig.entryTtl(Duration.ofMinutes(5)));
        cacheConfigurations.put("reportVariants", defaultConfig.entryTtl(Duration.ofMinutes(5)));

        RedisCacheManager cacheManager = RedisCacheManager.builder(connectionFactory)
                .cacheDefaults(defaultConfig)
                .withInitialCacheConfigurations(cacheConfigurations)
                .transactionAware()
                .build();

        log.info("Redis cache manager initialized with secure type validation. Caches: {}", cacheConfigurations.keySet());
        return cacheManager;
    }

    @Bean
    public CacheErrorHandler errorHandler() {
        return new CacheErrorHandler() {
            @Override
            public void handleCacheGetError(RuntimeException ex, org.springframework.cache.Cache cache, Object key) {
                log.error("Cache GET error for cache='{}': {}", cache.getName(), ex.getMessage());
            }

            @Override
            public void handleCachePutError(RuntimeException ex, org.springframework.cache.Cache cache, Object key, Object value) {
                log.error("Cache PUT error for cache='{}': {}", cache.getName(), ex.getMessage());
            }

            @Override
            public void handleCacheEvictError(RuntimeException ex, org.springframework.cache.Cache cache, Object key) {
                log.error("Cache EVICT error for cache='{}': {}", cache.getName(), ex.getMessage());
            }

            @Override
            public void handleCacheClearError(RuntimeException ex, org.springframework.cache.Cache cache) {
                log.error("Cache CLEAR error for cache='{}': {}", cache.getName(), ex.getMessage());
            }
        };
    }
}
