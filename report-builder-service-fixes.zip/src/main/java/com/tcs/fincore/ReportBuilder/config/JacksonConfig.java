package com.tcs.fincore.ReportBuilder.config;

import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.SerializationFeature;

/**
 * Jackson 3 / Spring Boot 4 configuration.
 *
 * <p>Spring Boot 4 ships Jackson 3 ({@code tools.jackson.*}) as its default JSON engine and
 * auto-configures a single {@code JsonMapper} bean used by Spring MVC's HTTP message converters
 * and by every {@code JsonMapper}/{@code ObjectMapper}-typed constructor injection in this app
 * (see {@code ReportTemplateRepository}, {@code TemplateCloner},
 * {@code RedisBatchResultStore}, {@code RedisBatchJobStatusStore}, etc.).
 *
 * <p>Rather than replacing that bean outright with a hand-built {@code @Primary} mapper (the old
 * Jackson 2 pattern, which risks silently losing whatever modules/behavior Boot auto-registers),
 * we contribute to it via {@link JsonMapperBuilderCustomizer} — the Boot-recommended hook for
 * Jackson 3. This is a straight behavioral port of the previous Jackson 2 {@code ObjectMapper}
 * bean:
 * <ul>
 *   <li>FAIL_ON_UNKNOWN_PROPERTIES disabled — tolerates DB/API schema evolution without breaking
 *       deserialization (unknown fields are silently ignored).</li>
 *   <li>WRITE_DATES_AS_TIMESTAMPS disabled — ISO-8601 strings in JSON output.</li>
 * </ul>
 * Registering {@code JavaTimeModule} is no longer necessary: JSR-310 support
 * (LocalDate/LocalDateTime/Instant/...) ships built into jackson-databind 3.x.
 */
@Configuration
public class JacksonConfig {

    @Bean
    public JsonMapperBuilderCustomizer jsonMapperBuilderCustomizer() {
        return builder -> builder
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
}
