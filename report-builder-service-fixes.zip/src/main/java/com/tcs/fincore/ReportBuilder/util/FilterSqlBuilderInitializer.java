package com.tcs.fincore.ReportBuilder.util;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Wires {@code report.batch.filter.*} properties into {@link FilterSqlBuilder}'s configurable
 * limits.
 *
 * <p>Bug fixed: {@code application.properties} previously set
 * {@code report.batch.filter.max-in-values=10000}, but {@link FilterSqlBuilder} enforced a
 * hardcoded {@code 40_000} that ignored the property entirely — the configured value and the
 * actual enforced value silently disagreed. {@link FilterSqlBuilder} now exposes package-visible
 * setters and this component applies the real configuration once at startup, so the property
 * file is no longer misleading and the limit is deployment-tunable without a rebuild.
 */
@Slf4j
@Component
public class FilterSqlBuilderInitializer {

    private final int maxInValues;
    private final int maxFilterConditions;

    public FilterSqlBuilderInitializer(
            @Value("${report.batch.filter.max-in-values:40000}") int maxInValues,
            @Value("${report.batch.filter.max-conditions:50}") int maxFilterConditions) {
        this.maxInValues = maxInValues;
        this.maxFilterConditions = maxFilterConditions;
    }

    @PostConstruct
    public void apply() {
        FilterSqlBuilder.configureLimits(maxInValues, maxFilterConditions);
        log.info("FilterSqlBuilder limits configured: maxInValues={}, maxFilterConditions={}",
                maxInValues, maxFilterConditions);
    }
}
